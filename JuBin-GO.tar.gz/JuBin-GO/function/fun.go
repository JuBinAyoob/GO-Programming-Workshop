package main

import "fmt"

func sayHello(name string,lastName string){
	fmt.Printf("Hello %s %s\n",name,lastName)
}

func main(){
	
	sayHello("JuBee....","Ayoob")
}

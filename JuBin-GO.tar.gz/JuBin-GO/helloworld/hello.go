package main

import "fmt"

func main(){
	fmt.Println("Hello World")
	fmt.Printf("IM JUbin\n %s \n","Hai.....\n")
}

package main

import "fmt"

func main(){
	var num int
	num=20
	fmt.Printf("\n\nnum=== %d     stored......\n",num)
}
